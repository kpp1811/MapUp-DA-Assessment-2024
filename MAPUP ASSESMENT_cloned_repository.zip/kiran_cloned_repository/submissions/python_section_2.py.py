import pandas as pd


def calculate_distance_matrix(df)->pd.DataFrame():
    """
    Calculate a distance matrix based on the dataframe, df.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame: Distance matrix
    """
import pandas as pd

def calculate_distance_matrix(csv_file):
    # Read the dataset from CSV
    df = pd.read_csv(csv_file)
    
    # Extract unique locations (IDs)
    locations = sorted(set(df['Location_A']).union(set(df['Location_B'])))
    
    # Initialize the matrix with NaN values
    distance_matrix = pd.DataFrame(float('inf'), index=locations, columns=locations)
    
    # Set diagonal to 0 (distance from a location to itself)
    for location in locations:
        distance_matrix.loc[location, location] = 0
    
    # Fill the matrix with direct distances
    for _, row in df.iterrows():
        loc_a, loc_b, dist = row['Location_A'], row['Location_B'], row['Distance']
        distance_matrix.loc[loc_a, loc_b] = dist
        distance_matrix.loc[loc_b, loc_a] = dist  # Ensure symmetry
    
    # Apply Floyd-Warshall Algorithm to compute shortest cumulative distances
    for k in locations:
        for i in locations:
            for j in locations:
                distance_matrix.loc[i, j] = min(distance_matrix.loc[i, j], distance_matrix.loc[i, k] + distance_matrix.loc[k, j])
    
    return distance_matrix


def unroll_distance_matrix(df)->pd.DataFrame():
    """
    Unroll a distance matrix to a DataFrame in the style of the initial dataset.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame: Unrolled DataFrame containing columns 'id_start', 'id_end', and 'distance'.
    """
def unroll_distance_matrix(matrix):
    # Create an empty DataFrame
    unrolled = pd.DataFrame(columns=['id_start', 'id_end', 'distance'])
    
    # Unroll the matrix into three columns: id_start, id_end, and distance
    for i, start_id in enumerate(matrix.index):
        for j, end_id in enumerate(matrix.columns):
            if start_id != end_id:  # Skip the same-location pairs
                distance = matrix.iloc[i, j]
                unrolled = unrolled.append({'id_start': start_id, 'id_end': end_id, 'distance': distance}, ignore_index=True)
    
    return unrolled


def find_ids_within_ten_percentage_threshold(df, reference_id)->pd.DataFrame():
    """
    Find all IDs whose average distance lies within 10% of the average distance of the reference ID.

    Args:
        df (pandas.DataFrame)
        reference_id (int)

    Returns:
        pandas.DataFrame: DataFrame with IDs whose average distance is within the specified percentage threshold
                          of the reference ID's average distance.
    """
import pandas as pd

def find_ids_within_ten_percentage_threshold(unrolled_df, reference_value):
    # Filter rows where id_start matches the reference value
    reference_distances = unrolled_df[unrolled_df['id_start'] == reference_value]['distance']
    
    # Calculate the average distance for the reference value
    avg_distance = reference_distances.mean()
    
    # Calculate the 10% threshold (floor and ceiling)
    lower_bound = avg_distance * 0.9  # 90% of the average distance
    upper_bound = avg_distance * 1.1  # 110% of the average distance
    
    # Group by id_start and calculate average distance for each id_start
    avg_distances_by_id = unrolled_df.groupby('id_start')['distance'].mean()
    
    # Find all id_start values whose average distance falls within the threshold
    ids_within_threshold = avg_distances_by_id[
        (avg_distances_by_id >= lower_bound) & (avg_distances_by_id <= upper_bound)
    ].index.tolist()
    
    # Return the sorted list of ids
    return sorted(ids_within_threshold)



def calculate_toll_rate(df)->pd.DataFrame():
    """
    Calculate toll rates for each vehicle type based on the unrolled DataFrame.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame
    """
import pandas as pd

def calculate_toll_rate(df):
    """
    Calculate toll rates based on vehicle types and add them as new columns to the DataFrame.
    
    Parameters:
    df (DataFrame): DataFrame containing a 'distance' column.
    
    Returns:
    DataFrame: The original DataFrame with additional columns for toll rates.
    """
    
    # Define the rate coefficients for each vehicle type
    rate_coefficients = {
        'moto': 0.8,
        'car': 1.2,
        'rv': 1.5,
        'bus': 2.2,
        'truck': 3.6
    }
    
    # Calculate toll rates and add them as new columns
    for vehicle_type, rate in rate_coefficients.items():
        df[vehicle_type] = df['distance'] * rate
    
    return df


def calculate_time_based_toll_rates(df)->pd.DataFrame():
    """
    Calculate time-based toll rates for different time intervals within a day.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame
    """
import pandas as pd
import datetime

def calculate_time_based_toll_rates(df):
    # Define discount factors for weekdays and weekends
    weekday_discounts = [
        (datetime.time(0, 0, 0), datetime.time(10, 0, 0), 0.8),  # 00:00 - 10:00
        (datetime.time(10, 0, 0), datetime.time(18, 0, 0), 1.2),  # 10:00 - 18:00
        (datetime.time(18, 0, 0), datetime.time(23, 59, 59), 0.8)  # 18:00 - 23:59
    ]
    
    weekend_discount = 0.7
    
    # Define days of the week
    weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    weekends = ['Saturday', 'Sunday']
    
    # List to hold the result rows
    result_rows = []
    
    # Iterate over the original DataFrame (from Question 12)
    for _, row in df.iterrows():
        id_start = row['id_start']
        id_end = row['id_end']
        
        # For each weekday, apply weekday discounts
        for day in weekdays:
            for start_time, end_time, discount_factor in weekday_discounts:
                # Copy the vehicle rates and apply the discount factor
                row_copy = row.copy()
                row_copy['start_day'] = day
                row_copy['end_day'] = day
                row_copy['start_time'] = start_time
                row_copy['end_time'] = end_time
                
                # Apply the discount factor to each vehicle type
                for vehicle in ['moto', 'car', 'rv', 'bus', 'truck']:
                    row_copy[vehicle] = row[vehicle] * discount_factor
                
                # Append the row to the result
                result_rows.append(row_copy)
        
        # For each weekend day, apply weekend discounts (constant for all times)
        for day in weekends:
            row_copy = row.copy()
            row_copy['start_day'] = day
            row_copy['end_day'] = day
            row_copy['start_time'] = datetime.time(0, 0, 0)
            row_copy['end_time'] = datetime.time(23, 59, 59)
            
            # Apply the weekend discount factor to each vehicle type
            for vehicle in ['moto', 'car', 'rv', 'bus', 'truck']:
                row_copy[vehicle] = row[vehicle] * weekend_discount
            
            # Append the row to the result
            result_rows.append(row_copy)
    
    # Convert the list of rows into a DataFrame
    result_df = pd.DataFrame(result_rows)
    
    return result_df

