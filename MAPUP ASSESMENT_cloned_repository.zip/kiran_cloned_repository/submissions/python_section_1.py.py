from typing import Dict, List

import pandas as pd


def reverse_by_n_elements(lst: List[int], n: int) -> List[int]:
    """
    Reverses the input list by groups of n elements.
    """
def reverse_in_groups(lst, n):
    result = []
    length = len(lst)
    
    for i in range(0, length, n):
        # Determine the end of the current group
        end = min(i + n, length)
        group = []
        
        # Collect elements for the current group
        for j in range(i, end):
            group.append(lst[j])
        
        # Reverse the current group without using slicing or reverse
        group_length = len(group)
        for k in range(group_length // 2):
            # Swap elements
            group[k], group[group_length - 1 - k] = group[group_length - 1 - k], group[k]
        
        # Add the reversed group to the result
        result.extend(group)
    
    return result
    


def group_by_length(lst: List[str]) -> Dict[int, List[str]]:
    """
    Groups the strings by their length and returns a dictionary.
    """
def group_strings_by_length(strings):
    length_dict = {}
    
    for string in strings:
        length = len(string)
        # If the length is not in the dictionary, initialize it with an empty list
        if length not in length_dict:
            length_dict[length] = []
        # Append the string to the list corresponding to its length
        length_dict[length].append(string)
    
    # Sort the dictionary by keys and return the result
    return dict(sorted(length_dict.items()))


def flatten_dict(nested_dict: Dict, sep: str = '.') -> Dict:
    """
    Flattens a nested dictionary into a single-level dictionary with dot notation for keys.
    
    :param nested_dict: The dictionary object to flatten
    :param sep: The separator to use between parent and child keys (defaults to '.')
    :return: A flattened dictionary
    """
def flatten_dict(d, parent_key='', sep='.'):
    items = []  # Will hold the flattened dictionary items
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k  # Append the key
        
        if isinstance(v, dict):
            # Recursively flatten the dictionary
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        elif isinstance(v, list):
            # If the value is a list, iterate over it and flatten each element
            for i, item in enumerate(v):
                items.extend(flatten_dict(item, f"{new_key}[{i}]", sep=sep).items())
        else:
            # If it's not a dictionary or list, add it as is
            items.append((new_key, v))
    return dict(items)
    

def unique_permutations(nums: List[int]) -> List[List[int]]:
    """
    Generate all unique permutations of a list that may contain duplicates.
    
    :param nums: List of integers (may contain duplicates)
    :return: List of unique permutations
    """
def unique_permutations(nums):
    def backtrack(curr_permutation):
        if len(curr_permutation) == len(nums):
            result.append(curr_permutation[:])
            return
        
        for i in range(len(nums)):
            if used[i]:
                continue
            # Skip duplicates: ensure this value isn't used if it's a duplicate of the previous
            if i > 0 and nums[i] == nums[i - 1] and not used[i - 1]:
                continue
            
            # Mark this element as used
            used[i] = True
            curr_permutation.append(nums[i])
            
            # Continue building the permutation
            backtrack(curr_permutation)
            
            # Backtrack: unmark the element and remove it from the current permutation
            curr_permutation.pop()
            used[i] = False

    # Sort the numbers to easily handle duplicates
    nums.sort()
    
    result = []
    used = [False] * len(nums)  # Track used elements
    backtrack([])
    
    return result
    


def find_all_dates(text: str) -> List[str]:
    """
    This function takes a string as input and returns a list of valid dates
    in 'dd-mm-yyyy', 'mm/dd/yyyy', or 'yyyy.mm.dd' format found in the string.
    
    Parameters:
    text (str): A string containing the dates in various formats.

    Returns:
    List[str]: A list of valid dates in the formats specified.
    """
import re

def find_all_dates(text):
    # Define the regular expressions for the three date formats
    date_pattern = r'\b\d{2}-\d{2}-\d{4}\b'  # dd-mm-yyyy
    date_pattern += r'|\b\d{2}/\d{2}/\d{4}\b'  # mm/dd/yyyy
    date_pattern += r'|\b\d{4}\.\d{2}\.\d{2}\b'  # yyyy.mm.dd

    # Use re.findall to get all matching dates
    dates = re.findall(date_pattern, text)
    
    return dates

def polyline_to_dataframe(polyline_str: str) -> pd.DataFrame:
    """
    Converts a polyline string into a DataFrame with latitude, longitude, and distance between consecutive points.
    
    Args:
        polyline_str (str): The encoded polyline string.

    Returns:
        pd.DataFrame: A DataFrame containing latitude, longitude, and distance in meters.
    """
import polyline
import pandas as pd
import numpy as np
from math import radians, cos, sin, sqrt, atan2

# Haversine formula to calculate the distance between two points (in meters)
def haversine(lat1, lon1, lat2, lon2):
    R = 6371000  # Radius of the Earth in meters
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)
    a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c

# Function to decode polyline and calculate distances
def decode_polyline_with_distances(polyline_str):
    # Step 1: Decode the polyline into a list of (latitude, longitude) tuples
    coords = polyline.decode(polyline_str)
    
    # Step 2: Create a Pandas DataFrame
    df = pd.DataFrame(coords, columns=['latitude', 'longitude'])
    
    # Step 3: Calculate distances between successive points
    distances = [0]  # First point has a distance of 0
    for i in range(1, len(df)):
        lat1, lon1 = df.loc[i - 1, 'latitude'], df.loc[i - 1, 'longitude']
        lat2, lon2 = df.loc[i, 'latitude'], df.loc[i, 'longitude']
        distance = haversine(lat1, lon1, lat2, lon2)
        distances.append(distance)
    
    # Step 4: Add the distances to the DataFrame
    df['distance'] = distances
    
    return df


def rotate_and_multiply_matrix(matrix: List[List[int]]) -> List[List[int]]:
    """
    Rotate the given matrix by 90 degrees clockwise, then multiply each element 
    by the sum of its original row and column index before rotation.
    
    Args:
    - matrix (List[List[int]]): 2D list representing the matrix to be transformed.
    
    Returns:
    - List[List[int]]: A new 2D list representing the transformed matrix.
    """
import numpy as np

# Step 1: Function to rotate the matrix by 90 degrees clockwise
def rotate_90_clockwise(matrix):
    # Transpose the matrix (rows become columns)
    transposed_matrix = list(zip(*matrix))
    # Reverse each row of the transposed matrix
    rotated_matrix = [list(row)[::-1] for row in transposed_matrix]
    return rotated_matrix

# Step 2: Function to replace each element with the sum of its row and column, excluding itself
def transform_matrix(rotated_matrix):
    n = len(rotated_matrix)
    transformed_matrix = [[0] * n for _ in range(n)]
    
    for i in range(n):
        for j in range(n):
            # Sum of elements in row i (excluding the current element)
            row_sum = sum(rotated_matrix[i]) - rotated_matrix[i][j]
            # Sum of elements in column j (excluding the current element)
            col_sum = sum(rotated_matrix[k][j] for k in range(n)) - rotated_matrix[i][j]
            # The element is replaced by the sum of row and column sums
            transformed_matrix[i][j] = row_sum + col_sum
    
    return transformed_matrix

# Step 3: Combine the steps into the final function
def rotate_and_transform(matrix):
    # Step 1: Rotate the matrix by 90 degrees clockwise
    rotated_matrix = rotate_90_clockwise(matrix)
    
    # Step 2: Transform the rotated matrix
    final_matrix = transform_matrix(rotated_matrix)
    
    return final_matrix


def time_check(df) -> pd.Series:
    """
    Use shared dataset-2 to verify the completeness of the data by checking whether the timestamps for each unique (`id`, `id_2`) pair cover a full 24-hour and 7 days period

    Args:
        df (pandas.DataFrame)

    Returns:
        pd.Series: return a boolean series
    """
import pandas as pd
from datetime import datetime, timedelta

# Function to check if a time range covers a full 24 hours
def is_full_day_covered(start_time, end_time):
    # Convert start and end times to datetime objects
    start_time = datetime.strptime(start_time, '%H:%M:%S')
    end_time = datetime.strptime(end_time, '%H:%M:%S')
    
    # Check if the time range covers the full day
    return start_time == datetime.strptime('00:00:00', '%H:%M:%S') and end_time == datetime.strptime('23:59:59', '%H:%M:%S')

# Function to check if the timestamps cover the full week and 24 hours each day
def check_time_completeness(df):
    # Initialize an empty list to store results
    results = []
    
    # Group by id and id_2
    grouped = df.groupby(['id', 'id_2'])
    
    # Iterate over each (id, id_2) pair
    for (id_val, id2_val), group in grouped:
        # Track days covered
        days_covered = set()
        
        # Flag to indicate if any day is incomplete
        incomplete_time = False
        
        # Iterate over rows in the group
        for _, row in group.iterrows():
            start_day = row['startDay']
            end_day = row['endDay']
            start_time = row['startTime']
            end_time = row['endTime']
            
            # Check if the current day is covered fully
            if not is_full_day_covered(start_time, end_time):
                incomplete_time = True
            
            # Add the start and end days to the set of covered days
            days_covered.update(range(start_day, end_day + 1))
        
        # Check if all 7 days are covered and no incomplete times were found
        full_week_covered = set(range(1, 8)) == days_covered
        is_incomplete = not full_week_covered or incomplete_time
        
        # Append the result (True if incomplete, False if complete)
        results.append(((id_val, id2_val), is_incomplete))
    
    # Convert results to a Pandas Series with multi-index
    index = pd.MultiIndex.from_tuples([x[0] for x in results], names=['id', 'id_2'])
    boolean_series = pd.Series([x[1] for x in results], index=index)
    
    return boolean_series

    
